/**This class is part of the Autonomous Navigation Simulator 2015,
Written by Nick Sullivan, University of Adelaide.
*/

package simulator.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.AffineTransform;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.ConcurrentModificationException;

import simulator.maps.RealMap;
import simulator.interfaces.MapListener;


public class RealMapGUI implements MapListener{
	private RealMap map;				//Link to the map we're displaying
	private MyCanvas canvas;			//An overriden JComponent for drawing on
	
	private JFrame window;				//The window
	private JPanel panel;				//panel inside window

	public RealMapGUI(RealMap map){
		//Establish connections
		this.map = map;
		map.addListener(this);
		canvas = new MyCanvas(map.getWidth(), map.getHeight());
		
		//Set the canvas once
		canvas.setObstacles(map.getObstacles());
		canvas.setLines(map.getLines());
		canvas.setLasers(map.getLasers());
		canvas.setVehiclePosition(map.getVehiclePosX(), map.getVehiclePosY(), map.getVehicleAng());
	}
	
	/*Displays the GUI. Should only be called once, after initialisation.*/
	public void display(){
		//Create the window
		window = new JFrame("Real Map");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLocation(50, 50);
		window.setResizable(true);
		
		//Create the window panel
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setPreferredSize(new Dimension(500, 500));
		panel.setBackground(Color.WHITE);
		window.setContentPane(panel);
		
		//Add the display
		panel.add(canvas);
		
		//Display the window
		window.pack();
		window.setVisible(true);	
	}
	
	/********************************************
	* Listener methods 							*
	*********************************************/
	public void mapHasChanged(){
		canvas.setObstacles(map.getObstacles());
		canvas.setLines(map.getLines());
		canvas.setLasers(map.getLasers());
		canvas.setVehiclePosition(map.getVehiclePosX(), map.getVehiclePosY(), map.getVehicleAng());
		canvas.setDestinationPosition(map.getDestinationPosX(), map.getDestinationPosY());
	}
	
	
	/********************************************
	* Canvas to draw on							*
	*********************************************/
	private class MyCanvas extends JComponent {
		private double width;		//The width of the map, in m
		private double height;		//The height of the map, in m

		private LinkedList<Ellipse2D.Double> obstacles;
		private LinkedList<Ellipse2D.Double> lines;		
		private LinkedList<Line2D.Double> lasers;		//In m,m - pixel coordinates
		private double vehiclePosX;		//The X position of the vehicle, in m (pixel coordinates)
		private double vehiclePosY;		//The Y position of the vehicle, in m (pixel coordinates)
		private double vehicleAng;		//The orientation of the vehicle, in degrees (CCW from East)
		private double destPosX;		//The X position of the destination, in m (pixel coordinates);
		private double destPosY;		//The Y position of the destination, in m (pixel coordinates);
		
		public MyCanvas(double width, double height){
			this.width = width;
			this.height = height;
			obstacles = new LinkedList<Ellipse2D.Double>();
			lines = new LinkedList<Ellipse2D.Double>();
			lasers = new LinkedList<Line2D.Double>();
			vehiclePosX = 0;
			vehiclePosY = 0;
			vehicleAng = 0;
			destPosX = 0;
			destPosY = 0;
		}
		
		@Override
		protected void paintComponent(Graphics g){
			Graphics2D g2d = (Graphics2D) g;
			Dimension size = getSize();
			
			try {
				//Add all the obstacles
				g2d.setColor(Color.BLACK);
				ListIterator<Ellipse2D.Double> iterator = obstacles.listIterator(0);
				while (iterator.hasNext()){
					Ellipse2D.Double circ = iterator.next();
					double normX = circ.getX() / width;	//normalise position
					double normW = circ.getWidth() / width;
					double normY = circ.getY() / height;
					double normH = circ.getHeight() / height;
					
					double x = normX * size.getWidth();
					double w = normW * size.getWidth();
					double y = normY * size.getHeight();
					double h = normH * size.getHeight();
					g2d.fill(new Ellipse2D.Double(x, y, w, h));
				}
			} catch (ConcurrentModificationException e){
			}
			
			
			try {
				//Add all the lines
				g2d.setColor(Color.GRAY);
				ListIterator<Ellipse2D.Double> iterator = lines.listIterator(0);
				while (iterator.hasNext()){
					Ellipse2D.Double circ = iterator.next();
					double normX = circ.getX() / width;	//normalise position
					double normW = circ.getWidth() / width;
					double normY = circ.getY() / height;
					double normH = circ.getHeight() / height;
					
					double x = normX * size.getWidth();
					double w = normW * size.getWidth();
					double y = normY * size.getHeight();
					double h = normH * size.getHeight();
					g2d.fill(new Ellipse2D.Double(x, y, w, h));
				}
			} catch (ConcurrentModificationException e){
			}

			try {
				//Add all the lasers
				g2d.setColor(Color.RED);
				ListIterator<Line2D.Double> iter = lasers.listIterator(0);
				while (iter.hasNext()){
					Line2D.Double laser = iter.next();
					double normX1 = laser.getX1() / width;	//normalise position
					double normX2 = laser.getX2() / width;
					double normY1 = laser.getY1() / height;
					double normY2 = laser.getY2() / height;
					
					double x1 = normX1 * size.getWidth();
					double x2 = normX2 * size.getWidth();
					double y1 = normY1 * size.getHeight();
					double y2 = normY2 * size.getHeight();
									
					g2d.draw(new Line2D.Double(x1, y1, x2, y2));
				}
			} catch (ConcurrentModificationException e){
			}
			
			//Add the destination
			double diameter = 10.0;
			double normX = destPosX / width;		//normalise position
			double normY = destPosY / height;
			double destX = normX * size.getWidth() - diameter/2.0;			//set to pixel values
			double destY = normY * size.getHeight() - diameter/2.0;
			g2d.setColor(Color.GREEN);
			g2d.fill(new Ellipse2D.Double(destX, destY, diameter, diameter));
				
			//Add the vehicle
			normX = vehiclePosX / width;		//normalise position
			normY = vehiclePosY / height;
			double vehX = normX * size.getWidth();			//set to pixel values
			double vehY = normY * size.getHeight();
			g2d.setColor(Color.BLUE);
			Rectangle2D.Double rectangle = new Rectangle2D.Double(vehX-10.0/2.0, vehY-5.0/2.0, 10.0, 5.0);
			AffineTransform transform = new AffineTransform();
			transform.rotate(-Math.toRadians(vehicleAng), rectangle.getX() + rectangle.width/2, rectangle.getY() + rectangle.height/2);
			Shape transformed = transform.createTransformedShape(rectangle);
			g2d.fill(transformed);
				
				
		}
		/********************************************
		* Getters and Setters						*
		*********************************************/
		
		public void setObstacles(LinkedList<Ellipse2D.Double> obstacles){
			this.obstacles = obstacles;
			repaint();
		}
		public void setLines(LinkedList<Ellipse2D.Double> lines){
			this.lines = lines;
			repaint();
		}
		
		public void setLasers(LinkedList<Line2D.Double> lasers){
			this.lasers = lasers;
			repaint();
		}
		
		public void setVehiclePosition(double posX, double posY, double ang){
			vehiclePosX = posX;
			vehiclePosY = posY;
			vehicleAng = ang;
		}
		
		public void setDestinationPosition(double posX, double posY){
			destPosX = posX;
			destPosY = posY;
		}
		
	}
}
