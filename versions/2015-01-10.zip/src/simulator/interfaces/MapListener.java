/**This class is part of the Autonomous Navigation Simulator 2015,
Written by Nick Sullivan, Adelaide Uni.
*/

package simulator.interfaces;

public interface MapListener{
	public void mapHasChanged();
}
