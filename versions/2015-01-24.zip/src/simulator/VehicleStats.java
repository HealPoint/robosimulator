/**This class is part of the Autonomous Navigation Simulator 2015,
Written by Nick Sullivan, Adelaide Uni.
*/
package simulator;

/* Assumptions: 
LIDAR sweep and camera range is assumed to be symmetrical about the centre (e.g if the camera
 range is 100 degrees, the vehicle will see 50 degrees to the left, and 50 degrees to the right).
The LIDAR and camera are placed at the front of the vehicle.
The robot can turn on the spot.
The robot is a rectangle.
The camera finds white lines in a similar way the LIDAR does.

Notes:
The vehicle position and orientation are NOT known by the vehicle, as this value may be different
 depending on the map.
*/
public class VehicleStats{
	private double lidarRange;		//How far the LIDAR sweeps in degrees (usually 180 or 100)
	private double lidarIncrement;	//The precision of the LIDAR sweep in degrees (usually 0.5 or 1.0)
	private double lidarDistance;	//The maximum distance an obstacle can be seen, in metres (usually 8.0)
	private double lidarPeriod;		//The time it takes the LIDAR to perform a full sweep, in s
	private double cameraRange;		//How far the camera sweeps in degrees
	private double cameraIncrement;	//The precision of the camera sweep in degrees (usually 0.5 or 1.0)
	private double cameraDistance;	//The maximum distance a white line can be seen, in metres
	private double cameraPeriod;	//The time it takes the camera to analyse an image, in s
	private double linVelocity;		//The velocity of the vehicle in a straight line, in m/s
	private double rotVelocity;		//The velocity of the vehicle rotating on the spot, in rad/s
	private double length;			//The length of the vehicle, in m
	private double width;			//The width of the vehicle, in m
	private double gpsError;		//The error of the GPS, in m
	private double imuError;		//The error of the IMU, in deg
	private long gpsUpdatePeriod;	//The time between successive GPS calls, in milliseconds
	private long imuUpdatePeriod;	//The time between successive IMU calls, in milliseconds
	
	public VehicleStats(){
		//LIDAR
		lidarRange = 180.0;
		lidarIncrement = 1.0;
		lidarDistance = 8.0;
		lidarPeriod = 1.0;
		
		//Camera
		cameraRange = 180.0;
		cameraIncrement = 1.0;
		cameraDistance = 2.0;
		cameraPeriod = 0.6;
		
		//Physical Capabilities
		linVelocity = 0.5;
		rotVelocity = 60.0;
		length = 0.5;
		width = 0.3;
		
		//GPS
		gpsError = 0.00;
		gpsUpdatePeriod = 500;
		
		//IMU
		imuError = 0.0;
		imuUpdatePeriod = 10;
	}
	
	/********************************************
	* Getters 									*
	*********************************************/
	public double getLidarRange(){
		return lidarRange;
	}
	public double getLidarIncrement(){
		return lidarIncrement;
	}
	public double getLidarDistance(){
		return lidarDistance;
	}
	public double getLidarPeriod(){
		return lidarPeriod;
	}
	public double getCameraRange(){
		return cameraRange;
	}
	public double getCameraIncrement(){
		return cameraIncrement;
	}
	public double getCameraDistance(){
		return cameraDistance;
	}
	public double getCameraPeriod(){
		return cameraPeriod;
	}
	public double getGpsError(){
		return gpsError;
	}
	public double getImuError(){
		return imuError;
	}
	public long getGpsUpdatePeriod(){
		return gpsUpdatePeriod;
	}
	public long getImuUpdatePeriod(){
		return imuUpdatePeriod;
	}
	public double getLinVelocity(){
		return linVelocity;
	}
	public double getRotVelocity(){
		return rotVelocity;
	}
}
