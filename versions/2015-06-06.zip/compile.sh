#!/bin/sh
javac -d bin -cp lib/miglayout-4.0-swing.jar src/simulator/interfaces/*.java src/simulator/navigators/*.java src/simulator/maps/*.java src/simulator/gui/*.java src/simulator/*.java
