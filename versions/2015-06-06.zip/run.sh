#!/bin/sh
java -cp bin:lib/miglayout-4.0-swing.jar simulator.Main
